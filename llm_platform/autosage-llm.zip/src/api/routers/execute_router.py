from fastapi import APIRouter

from src.api.models.execute_request import ExecuteAgentRequest
from src.api.models.execute_response import ExecuteAgentResponse
from src.api.services.execution_service import ExecutionService
from src.api.services.registry import (
    agent_service,
    knowledge_service,
    llm_adapter,
)

router = APIRouter(prefix="/execute", tags=["execution"])


_execution_service = ExecutionService(
    agent_service=agent_service,
    knowledge_service=knowledge_service,
    llm_adapter=llm_adapter,
)


@router.post("", response_model=ExecuteAgentResponse)
def execute(payload: ExecuteAgentRequest):
    response = _execution_service.execute(
        agent_id=payload.agent_id,
        user_input=payload.input,
    )

    return ExecuteAgentResponse(
        output=response.text,
        usage=response.usage.__dict__,
    )
