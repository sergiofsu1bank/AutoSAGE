from fastapi import APIRouter, Request

from src.api.models.agent_create import CreateAgentRequest
from src.api.models.agent_response import CreateAgentResponse
from src.api.services.agent_service import AgentService
from src.api.services.registry import agent_service


router = APIRouter(prefix="/agents", tags=["agents"])

_agent_service = AgentService()


@router.post("", response_model=CreateAgentResponse)
def create_agent(payload: CreateAgentRequest, request: Request):
    agent_id = _agent_service.create_agent(payload)

    return CreateAgentResponse(
        agent_id=agent_id,
        status="created",
    )
