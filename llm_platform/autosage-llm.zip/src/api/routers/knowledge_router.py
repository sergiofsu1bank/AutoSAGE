from fastapi import APIRouter

from src.api.models.knowledge_create import CreateKnowledgeRequest
from src.api.models.knowledge_response import CreateKnowledgeResponse
from src.api.services.registry import knowledge_service

router = APIRouter(prefix="/knowledge", tags=["knowledge"])


@router.post("", response_model=CreateKnowledgeResponse)
def create_knowledge(payload: CreateKnowledgeRequest):
    knowledge_id = knowledge_service.create_knowledge(
        agent_id=payload.agent_id,
        documents=payload.documents,
    )

    return CreateKnowledgeResponse(
        knowledge_id=knowledge_id,
        status="indexed",
    )
