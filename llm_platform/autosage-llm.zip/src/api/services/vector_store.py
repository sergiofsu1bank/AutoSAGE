from typing import Dict, List
from uuid import uuid4


class InMemoryVectorStore:
    def __init__(self):
        self._store: Dict[str, List[str]] = {}

    def add_documents(self, agent_id: str, documents: List[str]) -> str:
        knowledge_id = f"kb-{uuid4().hex}"
        self._store.setdefault(agent_id, []).extend(documents)
        return knowledge_id

    def get_documents(self, agent_id: str) -> List[str]:
        return self._store.get(agent_id, [])
