from src.api.services.agent_service import AgentService
from src.api.services.vector_store import InMemoryVectorStore
from src.api.services.knowledge_service import KnowledgeService
from src.app.llm.openai_adapter import OpenAIAdapter

# SINGLETONS DO PROCESSO
agent_service = AgentService()
vector_store = InMemoryVectorStore()
knowledge_service = KnowledgeService(vector_store)
llm_adapter = OpenAIAdapter()
