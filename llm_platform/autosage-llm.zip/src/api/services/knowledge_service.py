from src.api.services.vector_store import InMemoryVectorStore


class KnowledgeService:
    def __init__(self, vector_store: InMemoryVectorStore):
        self._vector_store = vector_store

    def create_knowledge(self, agent_id: str, documents):
        return self._vector_store.add_documents(agent_id, documents)
