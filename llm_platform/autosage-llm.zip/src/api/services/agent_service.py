from typing import Dict
from uuid import uuid4
from src.app.agents.contracts import AgentDefinition

class AgentService:
    """
    Service da camada API.
    Responsável apenas por criar, armazenar e recuperar agentes.
    """

    def __init__(self):
        self._agents: Dict[str, AgentDefinition] = {}

    def create_agent(self, payload) -> str:
        agent_id = f"agent-{uuid4().hex}"

        agent = AgentDefinition(
            name=payload.name,
            role=payload.role,
            model=payload.model,
            temperature=payload.temperature,
            max_tokens=payload.max_tokens,
            use_rag=payload.use_rag,
        )

        self._agents[agent_id] = agent
        return agent_id

    def get_agent(self, agent_id: str) -> AgentDefinition:
        return self._agents[agent_id]
