from pydantic import BaseModel, Field
from typing import Optional


class CreateAgentRequest(BaseModel):
    name: str = Field(..., min_length=1)
    role: str = Field(..., min_length=1)
    model: str = Field(..., min_length=1)
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    use_rag: bool = False
