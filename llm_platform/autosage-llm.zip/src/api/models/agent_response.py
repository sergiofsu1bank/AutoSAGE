from pydantic import BaseModel


class CreateAgentResponse(BaseModel):
    agent_id: str
    status: str
