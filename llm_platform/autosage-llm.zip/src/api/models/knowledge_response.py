from pydantic import BaseModel


class CreateKnowledgeResponse(BaseModel):
    knowledge_id: str
    status: str
