from pydantic import BaseModel
from typing import Optional, Dict


class ExecuteAgentResponse(BaseModel):
    output: str
    usage: Optional[Dict]
