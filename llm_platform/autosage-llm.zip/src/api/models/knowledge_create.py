from pydantic import BaseModel, Field
from typing import List


class CreateKnowledgeRequest(BaseModel):
    agent_id: str = Field(..., min_length=1)
    documents: List[str] = Field(..., min_items=1)
