from pydantic import BaseModel, Field, field_validator


class ExecuteAgentRequest(BaseModel):
    """
    Request de execução de um agente.

    Regra:
    - agent_id SEMPRE deve identificar um agente (prefixo 'agent-')
    - knowledge_id NUNCA entra aqui
    """

    agent_id: str = Field(..., min_length=1)
    input: str = Field(..., min_length=1)

    @field_validator("agent_id")
    @classmethod
    def validate_agent_id(cls, v: str) -> str:
        if not v.startswith("agent-"):
            raise ValueError("agent_id must start with 'agent-'")
        return v
