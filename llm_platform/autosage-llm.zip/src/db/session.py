import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from src.db.base import Base
import src.db.models  # registra os models no metadata

def init_db() -> None:
    Base.metadata.create_all(bind=engine)

DATABASE_HOST = os.getenv("DATABASE_HOST", "localhost")
DATABASE_PORT = os.getenv("DATABASE_PORT", "5444")
DATABASE_NAME = os.getenv("DATABASE_NAME", "llm_platform")
DATABASE_USER = os.getenv("DATABASE_USER", "postgres")
DATABASE_PASSWORD = os.getenv("DATABASE_PASSWORD", "postgres")

DATABASE_URL = (
    f"postgresql+psycopg2://{DATABASE_USER}:{DATABASE_PASSWORD}"
    f"@{DATABASE_HOST}:{DATABASE_PORT}/{DATABASE_NAME}"
)

engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,
)

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
)


def init_db() -> None:
    """
    Cria todas as tabelas registradas no Base.metadata.
    """
    Base.metadata.create_all(bind=engine)
