from pydantic import BaseModel, Field
from typing import Optional, Dict


class AgentDefinition(BaseModel):
    """
    Definição lógica de um agente.
    Não executa nada.
    """
    name: str = Field(..., min_length=1)
    role: str = Field(..., min_length=1)
    model: str = Field(..., min_length=1)
    use_rag: bool = False

    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    description: Optional[str] = None
