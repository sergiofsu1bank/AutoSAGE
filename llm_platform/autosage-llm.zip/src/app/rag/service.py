from dataclasses import dataclass
from typing import List, Dict, Any, Optional
import uuid
import time
from src.db.session import SessionLocal
from src.db.vector_repository import VectorRepository
from openai import OpenAI
import os


# ==================================================
# Exceptions
# ==================================================

class RAGServiceError(Exception):
    pass


class RAGIngestionError(RAGServiceError):
    pass


class RAGRetrievalError(RAGServiceError):
    pass


# ==================================================
# Contracts
# ==================================================

@dataclass(frozen=True)
class DocumentChunk:
    chunk_id: str
    content: str
    source: str
    score: float
    metadata: Dict[str, Any]


@dataclass(frozen=True)
class RAGQuery:
    query: str
    top_k: int = 5
    filters: Optional[Dict[str, Any]] = None


# ==================================================
# RAG Service
# ==================================================
class RAGService:
    """
    Database-backed RAG service.
    """

    def __init__(self) -> None:
        self._db = SessionLocal()
        self._repo = VectorRepository(self._db)
        self._openai = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

    # --------------------------------------------------
    # Ingestion
    # --------------------------------------------------
    def ingest(
        self,
        *,
        agent_id: str,
        content: str,
        source: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:

        if not content or not source:
            raise RAGIngestionError(
                "Both content and source are required."
            )

        embedding = self._embed(content)

        self._repo.insert_chunk(
            agent_id=agent_id,
            content=content,
            embedding=embedding,
            chunk_metadata={
                "source": source,
                **(metadata or {}),
            },
        )

    # --------------------------------------------------
    # Retrieval
    # --------------------------------------------------
    def retrieve(
        self,
        *,
        agent_id: str,
        query: RAGQuery,
    ) -> List[DocumentChunk]:

        if not query.query:
            raise RAGRetrievalError("Query text is required.")

        query_embedding = self._embed(query.query)

        results = self._repo.similarity_search(
            agent_id=agent_id,
            query_embedding=query_embedding,
            k=query.top_k,
        )

        documents: List[DocumentChunk] = []

        for row in results:
            documents.append(
                DocumentChunk(
                    chunk_id=str(row.id),
                    content=row.content,
                    source=row.chunk_metadata.get("source", ""),
                    score=1.0,
                    metadata=row.chunk_metadata or {},
                )
            )

        return documents

    # --------------------------------------------------
    # Helpers
    # --------------------------------------------------

    @staticmethod
    def _generate_chunk_id() -> str:
        return f"chunk-{uuid.uuid4().hex[:12]}"

    @staticmethod
    def _match_filters(
        metadata: Dict[str, Any],
        filters: Dict[str, Any],
    ) -> bool:
        for key, expected in filters.items():
            if metadata.get(key) != expected:
                return False
        return True

    def _embed(self, text: str) -> list[float]:
        response = self._openai.embeddings.create(
            model="text-embedding-3-small",
            input=text,
        )
        return response.data[0].embedding
