from datetime import datetime
from typing import Any, Optional

from src.app.agents.registry import AgentRegistry
from src.app.llm.openai_adapter import OpenAIAdapter, LLMRequest
from src.app.orchestration.context import ExecutionContext
from src.app.orchestration.contracts import PipelineDefinition, PipelineEdge


class ExecutionEngine:
    """
    Execution Engine responsável por:
    - executar agentes definidos no PipelineDefinition
    - registrar outputs por nó
    - registrar decisões de transição
    - NÃO avaliar Condition (condições são declarativas)
    """

    def __init__(
        self,
        registry: AgentRegistry,
        llm_adapter: OpenAIAdapter,
        rag_service: Optional[Any] = None,  # mantido apenas por compatibilidade
    ) -> None:
        self.registry = registry
        self.llm = llm_adapter
        self.rag = rag_service  # NÃO utilizado no momento

    def run(
        self,
        *,
        pipeline: PipelineDefinition,
        initial_input: Any,
    ) -> ExecutionContext:
        context = ExecutionContext(initial_input=initial_input)

        try:
            for node_id in pipeline.start_nodes:
                self._execute_node(
                    node_id=node_id,
                    pipeline=pipeline,
                    context=context,
                )
        except Exception as exc:
            context.errors.append(str(exc))
        finally:
            context.finished_at = datetime.utcnow()

        return context

    def _execute_node(
        self,
        *,
        node_id: str,
        pipeline: PipelineDefinition,
        context: ExecutionContext,
    ) -> None:
        node = pipeline.nodes[node_id]

        # ======================
        # Execução de agente
        # ======================
        if node.agent_name:
            agent_def = self.registry.get(node.agent_name)

            request = LLMRequest(
                system_prompt=agent_def.role,          # contrato real
                user_prompt=context.initial_input,     # entrada atual
                context=None,                           # RAG não assumido
                model=agent_def.model,
                temperature=agent_def.temperature,
                max_tokens=agent_def.max_tokens,
            )

            response = self.llm.generate(request)
            output = response.text

            context.outputs_by_node[node_id] = output

        else:
            # Placeholder explícito para agregações futuras
            context.outputs_by_node[node_id] = None
            output = None

        # ======================
        # Transições (edges)
        # ======================
        for edge in pipeline.edges:
            if edge.source != node_id:
                continue

            # Condition é declarativa → NÃO é avaliada
            if edge.condition is None:
                context.decision_log.append(
                    {
                        "from": edge.source,
                        "to": edge.target,
                        "condition": None,
                    }
                )
                self._execute_node(
                    node_id=edge.target,
                    pipeline=pipeline,
                    context=context,
                )
