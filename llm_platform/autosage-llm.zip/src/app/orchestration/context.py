from typing import Any, Dict, List
from datetime import datetime
from pydantic import BaseModel, Field
import uuid


class ExecutionContext(BaseModel):
    """
    Contexto de execução compatível com o pipeline funcional original.
    """

    # Identidade
    run_id: str = Field(default_factory=lambda: f"run-{uuid.uuid4().hex[:12]}")

    # Entrada
    initial_input: Any

    # Saídas e decisões
    outputs_by_node: Dict[str, Any] = Field(default_factory=dict)
    decision_log: List[Dict[str, Any]] = Field(default_factory=list)

    # Erros
    errors: List[str] = Field(default_factory=list)

    # Metadados temporais
    started_at: datetime = Field(default_factory=datetime.utcnow)
    finished_at: datetime | None = None
