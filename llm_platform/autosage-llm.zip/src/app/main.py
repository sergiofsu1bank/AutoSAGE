from dotenv import load_dotenv
load_dotenv()

from src.db.base import Base
from src.db.session import engine
from src.db import models

from src.app.agents.registry import AgentRegistry
from src.app.llm.openai_adapter import OpenAIAdapter
from src.app.rag.service import RAGService, RAGQuery
from src.app.orchestration.engine import ExecutionEngine
from src.app.orchestration.contracts import (
    PipelineDefinition,
    PipelineNode,
    PipelineEdge,
    Condition,
)

# Garantir criação das tabelas
Base.metadata.create_all(bind=engine)


# ==================================================
# Registry
# ==================================================

def build_registry() -> AgentRegistry:
    registry = AgentRegistry()
    registry.load_from_database()
    return registry


# ==================================================
# Pipeline
# ==================================================

def build_pipeline() -> PipelineDefinition:
    nodes = {
        "n1": PipelineNode(
            node_id="n1",
            agent_name="analista",
        ),
        "n2_curto": PipelineNode(
            node_id="n2_curto",
            agent_name="analista",
        ),
        "n3_longo": PipelineNode(
            node_id="n3_longo",
            agent_name="analista",
        ),
    }

    edges = [
        PipelineEdge(
            source="n1",
            target="n2_curto",
            condition=Condition(
                type="expression",
                expression="len(output['text']) < 400",
            ),
        ),
        PipelineEdge(
            source="n1",
            target="n3_longo",
            condition=Condition(
                type="expression",
                expression="len(output['text']) >= 400",
            ),
        ),
    ]

    return PipelineDefinition(
        nodes=nodes,
        edges=edges,
        start_nodes=["n1"],
        end_nodes=["n2_curto", "n3_longo"],
    )


# ==================================================
# Main
# ==================================================

def main() -> None:
    print("\n=== BOOTSTRAP ===")

    registry = build_registry()
    llm_adapter = OpenAIAdapter()

    engine = ExecutionEngine(
        registry=registry,
        llm_adapter=llm_adapter,
        rag_service=None,  # RAG não está plugado na engine ainda
    )

    pipeline = build_pipeline()

    print("\n=== EXECUTION ===")

    context = engine.run(
        pipeline=pipeline,
        initial_input="Explique o papel da IA generativa nas empresas.",
    )

    print("\n=== RESULT ===")
    for node_id, output in context.outputs_by_node.items():
        print(f"\nNODE: {node_id}")
        print(output)

    print("\n=== DECISIONS ===")
    for decision in context.decision_log:
        print(decision)

    print("\n=== ERRORS ===")
    for error in context.errors:
        print(error)

    print("\n=== METADATA ===")
    print(f"Run ID: {context.run_id}")
    print(f"Started at: {context.started_at}")
    print(f"Finished at: {context.finished_at}")

    # ==================================================
    # RAG TEST
    # ==================================================

    print("\n=== RAG TEST ===")

    rag = RAGService()

    agent_id = "1a980a44-f643-4f60-9e65-19fcc9c39664"

    results = rag.retrieve(
        agent_id=agent_id,
        query=RAGQuery(
            query="automação empresarial com IA",
            top_k=3,
        ),
    )

    print(f"Total encontrados: {len(results)}")

    for doc in results:
        print("\nCHUNK:")
        print(doc.content)
        print("Metadata:", doc.metadata)


if __name__ == "__main__":
    main()
