from src.app.orchestration.contracts import (
    PipelineDefinition,
    PipelineNode,
    PipelineEdge,
    Condition,
)

pipeline = PipelineDefinition(
    nodes={
        "__input__": PipelineNode(
            node_id="__input__",
            agent_name=None,
            aggregation_type=None
        ),

        "n1": PipelineNode(
            node_id="n1",
            agent_name="analista",
            output_key="analysis"
        ),

        "n2_reforco": PipelineNode(
            node_id="n2_reforco",
            agent_name="reforco",
            input_keys=["analysis"],
            output_key="refined"
        ),

        "n3_publicador": PipelineNode(
            node_id="n3_publicador",
            agent_name="publicador",
            input_keys=["analysis"],
            output_key="published"
        ),

        "n4_aggregator": PipelineNode(
            node_id="n4_aggregator",
            aggregation_type="merge"
        ),
    },

    edges=[
        PipelineEdge(source="__input__", target="n1"),

        PipelineEdge(
            source="n1",
            target="n2_reforco",
            condition=Condition(
                type="expression",
                expression="len(output['text']) < 400"
            )
        ),
        PipelineEdge(
            source="n1",
            target="n3_publicador",
            condition=Condition(
                type="expression",
                expression="len(output['text']) >= 400"
            )
        ),

        PipelineEdge(source="n2_reforco", target="n4_aggregator"),
        PipelineEdge(source="n3_publicador", target="n4_aggregator"),
    ],

    start_nodes=["__input__"],
    end_nodes=["n4_aggregator"],
)
